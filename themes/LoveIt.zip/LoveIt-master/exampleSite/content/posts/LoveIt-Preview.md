---
title: "LoveIt Theme Preview and Documentation"
date: 2019-08-25T16:22:42+08:00
lastmod: 2019-08-25T16:22:42+08:00
draft: false
description: "This is a LoveIt theme preview and documentation page."
show_in_homepage: true
show_description: false
license: ''

tags: ['Hugo', 'Theme']
categories: ['Documentation']

featured_image: ''
featured_image_preview: ''

comment: true
toc: true
autoCollapseToc: true
math: true
---

This is a [LoveIt](https://github.com/dillonzq/LoveIt) theme preview and documentation page.

<!--more-->