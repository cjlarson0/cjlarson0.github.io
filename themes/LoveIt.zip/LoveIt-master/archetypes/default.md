---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
lastmod: {{ .Date }}
draft: true
description: ""
show_in_homepage: true
show_description: false
license: ''

tags: []
categories: []

featured_image: ''
featured_image_preview: ''

comment: true
toc: false
autoCollapseToc: true
math: false
---

<!--more-->